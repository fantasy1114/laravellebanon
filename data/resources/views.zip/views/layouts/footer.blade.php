<footer class="footer footer-static footer-light">
    <p class="clearfix mb-0"><span class="float-md-left d-block d-md-inline-block mt-25">COPYRIGHT &copy; 2021<span class="d-none d-sm-inline-block">, PHP application</span></span><span class="float-md-right d-none d-md-block">Happy day<i data-feather="heart"></i></span></p>
</footer>
<button class="btn btn-primary btn-icon scroll-top" type="button"><i data-feather="arrow-up"></i></button>

 <!-- BEGIN: Vendor JS-->
 <script src="../../../app-assets/vendors/js/vendors.min.js"></script>
 <!-- BEGIN Vendor JS-->

 <script src="../../../app-assets/vendors/js/pickers/pickadate/picker.js"></script>
 <script src="../../../app-assets/vendors/js/pickers/pickadate/picker.date.js"></script>
 <script src="../../../app-assets/vendors/js/pickers/pickadate/picker.time.js"></script>
 <script src="../../../app-assets/vendors/js/pickers/pickadate/legacy.js"></script>
 <script src="../../../app-assets/vendors/js/pickers/flatpickr/flatpickr.min.js"></script>

 <!-- BEGIN: Page Vendor JS-->
 <script src="../../../app-assets/vendors/js/tables/datatable/jquery.dataTables.min.js"></script>
 <script src="../../../app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js"></script>
 <script src="../../../app-assets/vendors/js/tables/datatable/dataTables.responsive.min.js"></script>
 <script src="../../../app-assets/vendors/js/tables/datatable/responsive.bootstrap4.js"></script>
 <script src="../../../app-assets/vendors/js/tables/datatable/datatables.buttons.min.js"></script>
 <script src="../../../app-assets/vendors/js/tables/datatable/buttons.bootstrap4.min.js"></script>
 <script src="../../../app-assets/vendors/js/forms/validation/jquery.validate.min.js"></script>
 <script src="../../../app-assets/vendors/js/extensions/sweetalert2.all.min.js"></script>
 <script src="../../../app-assets/vendors/js/extensions/polyfill.min.js"></script>
 <!-- END: Page Vendor JS-->


 <script src="../../../app-assets/vendors/js/extensions/toastr.min.js"></script>
 <script src="../../../app-assets/js/scripts/extensions/ext-component-toastr.js"></script>
 <script src="../../../app-assets/js/scripts/extensions/ext-component-sweet-alerts.js"></script>
 
 <!-- BEGIN: Theme JS-->
 <script src="../../../app-assets/js/core/app-menu.js"></script>
 <script src="../../../app-assets/js/core/app.js"></script>
 <!-- END: Theme JS-->